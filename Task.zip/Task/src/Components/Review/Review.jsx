import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import { useState } from 'react';


function Review() {


  return (
    <Table striped bordered hover className='mt-4'>
      <thead>
        <tr>
          <th>Id</th>
          <th>Title</th>
          <th>Rating</th>
          <th>Description</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1</td>
          <td>domenty</td>
          <td> 3</td>
          <td>The man gave the police a detailed description.</td>
          <td>
            <Button type='delete' variant="danger">Delete</Button>
          </td>
        </tr>
      </tbody>
    </Table>
  );
}

export default Review;