import React, { useState } from 'react'
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';

function GiveReview() {

      const [create, setCreate] = useState({

            name : 'domenty',
            rating : '3',
            description : 'The man gave the police a detailed description.'

      })

      const handleChange = (e) => {

            let name = e.target.name;
            let value = e.target.value;

            setCreate({...create ,setCreate})

      }

      const handleSubmit = (e) => {

            e.preventDefault();

            setCreate({
                  name : '',
                  rating : '',
                  description : '' 
            })


      }
      

  return (
      <div className="container">
            <div className="box">
                  <h1 className='text-center d-inline-block'>Give Review</h1>
                  <span>Add + </span>
                  <Form onSubmit={handleSubmit}>
                        <label htmlFor="title">Title* : </label>
                        <input className='ms-2' type="text" name="title" value={create.name} onChange={handleChange}/>
                        <label htmlFor="rating">Rating* : </label>
                        <input className='ms-2' type="text" name="rating" value={create.rating} onChange={handleChange}/>
                        <label htmlFor="description">Description : </label>
                        <input className='ms-2' as="textarea" name="description" value={create.description} onChange={handleChange}/>
                        <Button className='m-4' type='submit' variant="success">Submit</Button>
                        <Button className='reset' type='reset' variant="info">Reset</Button>
                  </Form>
            </div>
      </div>
  );
}

export default GiveReview;